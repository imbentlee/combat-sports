var volkanovskiTable = false;

var koreanZombieTable = false;

var colbyTable = false;

var stylebenderTable = false;

var masvidalTable = false;

var hollowayTable = false;

var whittakerTable = false;

//break gap

var fighterName = "<h1>{{name}}</h1>";

var fillName = Handlebars.compile(fighterName);

var fighterStats = "<p>{{nickname}}<br>{{nation}}<br>{{age}}<br>{{height}}<br>{{weightclass}}<br>{{wins}}<br>{{losses}}<br>{{draws}}";

var fillStats = Handlebars.compile(fighterStats);

var fighters = [{name: 'Alexander "The Great" Volkanovski', nickname: '"The Great"', nation: 'Australia', age: '33', height: '5"6', weightclass: 'Featherweight (C)', wins: '22', losses: '1', draws: '0'},
                {name: 'Chan Sung Jung', nickname: '"The Korean Zombie"', nation: 'South Korea', age: '35', height: '5"9', weightclass: 'Featherweight (4)', wins: '17', losses: '6', draws: '0'},
                {name: 'Colby "Chaos" Covington', nickname: '"Chaos"', nation: 'Florida, USA', age: '34', height: '5"11', weightclass: 'Welterweight (1)', wins: '17', losses: '3', draws: '0'},
                {name: 'Israel "The Last Stylebender" Adesanya', nickname: '"The Last Stylebender"', nation: 'New Zealand', age: '32', height: '6"2', weightclass: 'Middleweight (C)', wins: '22', losses: '1', draws: '0'},
                {name: 'Jorge "Gamebred" Masvidal', nickname: '"Gamebred"', nation: 'Miami, USA', age: '37', height: '5"11', weightclass: 'Welterweight (7)', wins: '35', losses: '16', draws: '0'},
                {name: 'Max "Blessed" Holloway', nickname: '"Blessed"', nation: 'Hawaii, USA', age: '30', height: '5"9', weightclass: 'Featherweight (1)', wins: '25', losses: '6', draws: '0'},
                {name: 'Robert "The Reaper" Whittaker', nickname: '"The Reaper"', nation: 'Australia', age: '31', height: '6"0', weightclass: 'Welterweight (1)', wins: '23', losses: '6', draws: '0'}];

//fighter name

var volkanovskiName = fillName(fighters[0]);

var koreanZombieName = fillName(fighters[1]);
              
var colbyName = fillName(fighters[2]);
              
var stylebenderName = fillName(fighters[3]);
              
var masvidalName = fillName(fighters[4]);
              
var hollowayName = fillName(fighters[5]);
              
var whittakerName = fillName(fighters[6]);

//fighter stat

var volkanovski = fillStats(fighters[0]);

var koreanZombie = fillStats(fighters[1]);

var colby = fillStats(fighters[2]);

var stylebender = fillStats(fighters[3]);

var masvidal = fillStats(fighters[4]);

var holloway = fillStats(fighters[5]);

var whittaker = fillStats(fighters[6]);

//fight history table

var tableLabels =  ['Result','Opponent','Date','Method','Round','Time']

var volkanovksiHistory = [{result: 'Win', opponent: 'Brian Ortega', date: '25 Sep 2021', method: 'Decision (Unanimous)', round: '5', time: '5:00'},
                          {result: 'Win', opponent: 'Max Holloway', date: '11 Jul 2020', method: 'Decision (Split)', round: '5', time: '5:00'},
                          {result: 'Win', opponent: 'Max Holloway', date: '14 Dec 2019', method: 'Decision (Unanimous)', round: '5', time: '5:00'},
                          {result: 'Win', opponent: 'Jose Aldo', date: '11 May 2019', method: 'Decision (Unanimous)', round: '3', time: '5:00'},
                          {result: 'Win', opponent: 'Chad Mendes', date: '29 Dec 2018', method: 'TKO (Punches)', round: '2', time: '4:14'},
                          {result: 'Win', opponent: 'Darren Elkins', date: '14 Jul 2018', method: 'Decision (Unanimous)', round: '3', time: '5:00'},
                          {result: 'Win', opponent: 'Jeremy Kennedy', date: '10 Feb 2018', method: 'TKO (Punches)', round: '2', time: '4:57'},
                          {result: 'Win', opponent: 'Shane Young', date: '18 Nov 2017', method: 'Decision (Unanimous)', round: '3', time: '5:00'},
                          {result: 'Win', opponent: 'Mizuto Hirota', date: '10 Jun 2017', method: 'Decision (Unanimous)', round: '3', time: '5:00'},
                          {result: 'Win', opponent: 'Yusuke Kasuya', date: '26 Nov 2016', method: 'TKO (Punches)', round: '2', time: '2:06'}];

var koreanZombieHistory = [{result: 'Win', opponent: 'Dan Ige', date: '19 Jun 2021', method: 'Decision (Unanimous)', round: '5', time: '5:00'},
                          {result: 'Loss', opponent: 'Brian Ortega', date: '17 Oct 2020', method: 'Decision (Unanimous)', round: '5', time: '5:00'},
                          {result: 'Win', opponent: 'Frankie Edgar', date: '21 Dec 2019', method: 'TKO (Punches)', round: '1', time: '3:18'},
                          {result: 'Win', opponent: 'Renato Carneiro', date: '22 Jun 2019', method: 'TKO (Punches)', round: '1', time: '0:58'},
                          {result: 'Loss', opponent: 'Yair Rodriguez', date: '10 Nov 2018', method: 'KO (Elbow)', round: '5', time: '4:59'},
                          {result: 'Win', opponent: 'Dennis Bermudas', date: '04 Feb 2017', method: 'KO (Punch)', round: '1', time: '2:49'},
                          {result: 'Loss', opponent: 'Jose Aldo', date: '03 Aug 2013', method: 'TKO (Punches)', round: '4', time: '2:00'},
                          {result: 'Win', opponent: 'Dustin Poirier', date: '15 May 2012', method: "Submission (D'arce Choke)", round: '4', time: '1:07'},
                          {result: 'Win', opponent: 'Mark Hominick', date: '10 Dec 2011', method: 'KO (Punch)', round: '1', time: '0:07'},
                          {result: 'Win', opponent: 'Leonard Garcia', date: '26 Mar 2011', method: 'Submission (Twister)', round: '2', time: '4:59'}];

var colbyHistory =       [{result: 'Win', opponent: 'Jorge Masvidal', date: '05 Mar 2022', method: 'Decision (Unanimous)', round: '5', time: '5:00'},
                          {result: 'Loss', opponent: 'Kamaru Usman', date: '06 Nov 2021', method: 'Decision (Unanimous)', round: '5', time: '5:00'},
                          {result: 'Win', opponent: 'Tyron Woodley', date: '19 Sep 2020', method: 'TKO (Injury)', round: '5', time: '1:19'},
                          {result: 'Loss', opponent: 'Kamaru Usman', date: '14 Dec 2019', method: 'TKO (Punches)', round: '5', time: '4:10'},
                          {result: 'Win', opponent: 'Robbie Lawler', date: '03 Aug 2019', method: 'Decision (Unanimous)', round: '5', time: '5:00'},
                          {result: 'Win', opponent: 'Rafael dos Anjos', date: '09 Jun 2018', method: 'Decision (Unanimous)', round: '5', time: '5:00'},
                          {result: 'Win', opponent: 'Demian Maia', date: '28 Oct 2017', method: 'Decision (Unanimous)', round: '3', time: '5:00'},
                          {result: 'Win', opponent: 'Dong Hyun Kim', date: '17 Jun 2017', method: 'Decision (Unanimous)', round: '3', time: '5:00'},
                          {result: 'Win', opponent: 'Bryan Barberena', date: '17 Dec 2016', method: 'Decision (Unanimous)', round: '3', time: '5:00'},
                          {result: 'Win', opponent: 'Max Griffin', date: '20 Aug 2016', method: 'TKO (Punches)', round: '3', time: '2:18'}];

var stylebenderHistory = [{result: 'Win', opponent: 'Robert Whittaker', date: '12 Feb 2022', method: 'Decision (Unanimous)', round: '5', time: '5:00'},
                          {result: 'Win', opponent: 'Marvin Vettori', date: '12 Jun 2021', method: 'Decision (Unanimous)', round: '5', time: '5:00'},
                          {result: 'Loss', opponent: 'Jan Blachowicz', date: '06 Mar 2021', method: 'Decision (Unanimous)', round: '5', time: '5:00'},
                          {result: 'Win', opponent: 'Paulo Costa', date: '29 Sep 2020', method: 'TKO (Punches and Elbows)', round: '2', time: '3:59'},
                          {result: 'Win', opponent: 'Yoel Romero', date: '07 Mar 2020', method: 'Decision (Unanimous)', round: '5', time: '5:00'},
                          {result: 'Win', opponent: 'Robert Whittaker', date: '05 Oct 2019', method: 'KO (Punches)', round: '2', time: '3:33'},
                          {result: 'Win', opponent: 'Kelvin Gastelum', date: '13 Apr 2019', method: 'Decision (Unanimous)', round: '5', time: '5:00'},
                          {result: 'Win', opponent: 'Anderson Silva', date: '09 Feb 2019', method: 'Decision (Unanimous)', round: '3', time: '5:00'},
                          {result: 'Win', opponent: 'Derek Brunson', date: '03 Nov 2018', method: 'TKO (Knees and Punches)', round: '1', time: '4:51'},
                          {result: 'Win', opponent: 'Brad Tavares', date: '06 Jul 2018', method: 'Decision (Unanimous)', round: '5', time: '5:00'}];

var masvidalHistory =    [{result: 'Loss', opponent: 'Colby Covington', date: '05 Mar 2022', method: 'Decision (Unanimous)', round: '5', time: '5:00'},
                          {result: 'Loss', opponent: 'Kamaru Usman', date: '24 Apr 2021', method: 'KO (Punch)', round: '2', time: '1:02'},
                          {result: 'Loss', opponent: 'Kamaru Usman', date: '11 Jul 2020', method: 'Decision (Unanimous)', round: '5', time: '5:00'},
                          {result: 'Win', opponent: 'Nate Diaz', date: '02 Nov 2019', method: 'TKO (Doctor Stoppage)', round: '3', time: '5:00'},
                          {result: 'Win', opponent: 'Ben Askren', date: '06 Jul 2019', method: 'KO (Flying Knee)', round: '1', time: '0:05'},
                          {result: 'Win', opponent: 'Darren Till', date: '16 Mar 2019', method: 'KO (Punch)', round: '2', time: '3:05'},
                          {result: 'Loss', opponent: 'Stephen Thompson', date: '04 Nov 2017', method: 'Decision (Unanimous)', round: '3', time: '5:00'},
                          {result: 'Loss', opponent: 'Demian Maia', date: '13 May 2017', method: 'Decision (Split)', round: '3', time: '5:00'},
                          {result: 'Win', opponent: 'Donald Cerrone', date: '28 Jan 2017', method: 'TKO (Punches)', round: '2', time: '1:00'},
                          {result: 'Win', opponent: 'Jake Ellenberger', date: '03 Dec 2016', method: 'TKO (Punches)', round: '1', time: '4:05'}];

var hollowayHistory =    [{result: 'Win', opponent: 'Yair Rodriguez', date: '13 Nov 2021', method: 'Decision (Unanimous)', round: '5', time: '5:00'},
                          {result: 'Win', opponent: 'Calvin Kattar', date: '16 Jan 2021', method: 'Decision (Unanimous)', round: '5', time: '5:00'},
                          {result: 'Loss', opponent: 'Alexander Volkanovski', date: '11 Jul 2020', method: 'Decision (Split)', round: '5', time: '5:00'},
                          {result: 'Loss', opponent: 'Alexander Volkanovski', date: '14 Dec 2019', method: 'Decision (Unanimous)', round: '5', time: '5:00'},
                          {result: 'Win', opponent: 'Frankie Edgar', date: '27 Jul 2019', method: 'Decision (Unanimous)', round: '5', time: '5:00'},
                          {result: 'Loss', opponent: 'Dustin Poirier', date: '13 Apr 2019', method: 'Decision (Unanimous)', round: '5', time: '5:00'},
                          {result: 'Win', opponent: 'Brian Ortega', date: '08 Dec 2018', method: 'TKO (Doctor Stoppage)', round: '4', time: '5:00'},
                          {result: 'Win', opponent: 'Jose Aldo', date: '02 Dec 2017', method: 'TKO (Punches)', round: '3', time: '4:51'},
                          {result: 'Win', opponent: 'Jose Aldo', date: '03 Jun 2017', method: 'TKO (Punches)', round: '3', time: '4:13'},
                          {result: 'Win', opponent: 'Anthony Pettis', date: '10 Dec 2016', method: 'TKO (Body Kick and Punches)', round: '3', time: '4:50'}];

var whittakerHistory =   [{result: 'Loss', opponent: 'Israel Adesanya', date: '12 Feb 2022', method: 'Decision (Unanimous)', round: '5', time: '5:00'},
                          {result: 'Win', opponent: 'Kelvin Gastelum', date: '17 April 2021', method: 'Decision (Unanimous)', round: '5', time: '5:00'},
                          {result: 'Win', opponent: 'Jared Cannonier', date: '24 Oct 2020', method: 'Decision (Unanimous)', round: '3', time: '5:00'},
                          {result: 'Win', opponent: 'Darren Till', date: '25 Jul 2020', method: 'Decision (Unanimous)', round: '5', time: '5:00'},
                          {result: 'Loss', opponent: 'Israel Adesanya', date: '05 Oct 2019', method: 'KO (Punch)', round: '2', time: '3:33'},
                          {result: 'Win', opponent: 'Yoel Romero', date: '09 Jun 2018', method: 'Decision (Split)', round: '5', time: '5:00'},
                          {result: 'Win', opponent: 'Yoel Romero', date: '08 Jul 2017', method: 'Decision (Unanimous)', round: '5', time: '5:00'},
                          {result: 'Win', opponent: 'Ronaldo Souza', date: '15 Apr 2017', method: 'TKO (Head Kick and Punches)', round: '2', time: '3:28'},
                          {result: 'Win', opponent: 'Derek Brunson', date: '26 Nov 2016', method: 'TKO (Head Kick and Punches)', round: '1', time: '4:07'},
                          {result: 'Win', opponent: 'Rafael Natal', date: '23 Apr 2016', method: 'Decision (Unanimous)', round: '3', time: '5:00'}]

function drawTable(){
  var content = document.getElementById("fight-history-table");

  var tableTemplate = '<table><thead> <tr> <th>Result</th> <th>Opponent</th> <th>Date</th> <th>Method</th> <th>Round</th> <th>Time</th> </tr> </thead></tbody>';

  if(volkanovskiTable == true){
    for (var i=0;i<10;i++){

      tableTemplate += '<tr><td>' + volkanovksiHistory[i].result + '</td><td>' + volkanovksiHistory[i].opponent + '</td><td>' + volkanovksiHistory[i].date + '</td><td>' + volkanovksiHistory[i].method + '</td><td>' + volkanovksiHistory[i].round + '</td><td>' + volkanovksiHistory[i].time + '</td></tr>';
  
    }
  }else if(koreanZombieTable == true){
    for (var i=0;i<10;i++){

      tableTemplate += '<tr><td>' + koreanZombieHistory[i].result + '</td><td>' + koreanZombieHistory[i].opponent + '</td><td>' + koreanZombieHistory[i].date + '</td><td>' + koreanZombieHistory[i].method + '</td><td>' + koreanZombieHistory[i].round + '</td><td>' + koreanZombieHistory[i].time + '</td></tr>';
  
    }
  }else if(colbyTable == true){
    for (var i=0;i<10;i++){

      tableTemplate += '<tr><td>' + colbyHistory[i].result + '</td><td>' + colbyHistory[i].opponent + '</td><td>' + colbyHistory[i].date + '</td><td>' + colbyHistory[i].method + '</td><td>' + colbyHistory[i].round + '</td><td>' + colbyHistory[i].time + '</td></tr>';
  
    }
  }else if(stylebenderTable == true){
    for (var i=0;i<10;i++){

      tableTemplate += '<tr><td>' + stylebenderHistory[i].result + '</td><td>' + stylebenderHistory[i].opponent + '</td><td>' + stylebenderHistory[i].date + '</td><td>' + stylebenderHistory[i].method + '</td><td>' + stylebenderHistory[i].round + '</td><td>' + stylebenderHistory[i].time + '</td></tr>';
  
    }
  }else if(masvidalTable == true){
    for (var i=0;i<10;i++){

      tableTemplate += '<tr><td>' + masvidalHistory[i].result + '</td><td>' + masvidalHistory[i].opponent + '</td><td>' + masvidalHistory[i].date + '</td><td>' + masvidalHistory[i].method + '</td><td>' + masvidalHistory[i].round + '</td><td>' + masvidalHistory[i].time + '</td></tr>';
  
    }
  }else if(hollowayTable == true){
    for (var i=0;i<10;i++){

      tableTemplate += '<tr><td>' + hollowayHistory[i].result + '</td><td>' + hollowayHistory[i].opponent + '</td><td>' + hollowayHistory[i].date + '</td><td>' + hollowayHistory[i].method + '</td><td>' + hollowayHistory[i].round + '</td><td>' + hollowayHistory[i].time + '</td></tr>';
  
    }
  }else if(whittakerTable == true){
    for (var i=0;i<10;i++){

      tableTemplate += '<tr><td>' + whittakerHistory[i].result + '</td><td>' + whittakerHistory[i].opponent + '</td><td>' + whittakerHistory[i].date + '</td><td>' + whittakerHistory[i].method + '</td><td>' + whittakerHistory[i].round + '</td><td>' + whittakerHistory[i].time + '</td></tr>';
  
    }
  }

  tableTemplate += '</tbody><table>';

  content.innerHTML = tableTemplate;
}

function createVolkanovski(){
  volkanovskiTable = true;
  document.getElementById("fighter-image").src="assets/fighter-profile-imgs/volkanovski-profile-img.jpg";
  document.getElementById("athlete-name").innerHTML += volkanovskiName;
  document.getElementById("stat-value").innerHTML += volkanovski;
  drawTable();
  document.getElementById("highlights-video").src="https://www.youtube.com/embed/bimKDKIK-x0";
}

function createKoreanZombie(){
  koreanZombieTable = true;
  document.getElementById("fighter-image").src="assets/fighter-profile-imgs/koreanZombie-profile-img.jpg";
  document.getElementById("athlete-name").innerHTML += koreanZombieName;
  document.getElementById("stat-value").innerHTML += koreanZombie;
  drawTable();
  document.getElementById("highlights-video").src="https://www.youtube.com/embed/QOa2fHZz22Q";
}

function createColby(){
  colbyTable = true;
  document.getElementById("fighter-image").src="assets/fighter-profile-imgs/colby-profile-img.jpg";
  document.getElementById("athlete-name").innerHTML += colbyName;
  document.getElementById("stat-value").innerHTML += colby;
  drawTable();
  document.getElementById("highlights-video").src="https://www.youtube.com/embed/hQeyiAEI4FY";
}

function createStylebender(){
  stylebenderTable = true;
  document.getElementById("fighter-image").src="assets/fighter-profile-imgs/stylebender-profile-img.jpg";
  document.getElementById("athlete-name").innerHTML += stylebenderName;
  document.getElementById("stat-value").innerHTML += stylebender;
  drawTable();
  document.getElementById("highlights-video").src="https://www.youtube.com/embed/zea_QpSpfGs";
}

function createMasvidal(){
  masvidalTable = true;
  document.getElementById("fighter-image").src="assets/fighter-profile-imgs/masvidal-profile-img.jpg";
  document.getElementById("athlete-name").innerHTML += masvidalName;
  document.getElementById("stat-value").innerHTML += masvidal;
  drawTable();
  document.getElementById("highlights-video").src="https://www.youtube.com/embed/NxhfFWgDDEg";
}

function createHolloway(){
  hollowayTable = true;
  document.getElementById("fighter-image").src="assets/fighter-profile-imgs/holloway-profile-img.jpg";
  document.getElementById("athlete-name").innerHTML += hollowayName;
  document.getElementById("stat-value").innerHTML += holloway;
  drawTable();
  document.getElementById("highlights-video").src="https://www.youtube.com/embed/Fh-PoFV6Xdk";
}

function createWhittaker(){
  whittakerTable = true;
  document.getElementById("fighter-image").src="assets/fighter-profile-imgs/whittaker-profile-img.jpg";
  document.getElementById("athlete-name").innerHTML += whittakerName;
  document.getElementById("stat-value").innerHTML += whittaker;
  drawTable();
  document.getElementById("highlights-video").src="https://www.youtube.com/embed/4AFPwgcfuIg";
}